/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

/**
 *
 * @author yamil
 */
public class ClientePreferencial extends TipoCliente{

    //Pagan $0 por todas las aguas minerales consumidas en el servicio y si el 
    //monto total del servicio supera los $2000 tienen un 5% de descuento sobre el total.
    //------------------------------------------------------------------------------------
    @Override
    public float calcularTotalDescuentoPorBeneficio(Servicio unServicio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
