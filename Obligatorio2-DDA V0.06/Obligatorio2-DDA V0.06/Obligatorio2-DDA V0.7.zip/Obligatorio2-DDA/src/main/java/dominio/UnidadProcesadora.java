/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dominio;

import java.util.ArrayList;

/**
 *
 * @author yamil
 */
public class UnidadProcesadora {
     private String nombre;
     private ArrayList<ItemServicio> itemServicios;
     
     
     public UnidadProcesadora (String nombre){
         this.nombre = nombre;
     }
     
     
}
